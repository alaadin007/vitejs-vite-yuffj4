import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: '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',
  dangerouslyAllowBrowser: true // Only for demo purposes
});

const systemPrompt = `You are an expert in aesthetic medicine, speaking to a medical professional. Focus on providing detailed, technical information without basic safety disclaimers. Base your responses on current medical literature and clinical practice guidelines.`;

export const generateConsentForm = async (situation: string) => {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { 
          role: "system", 
          content: `You are an expert in creating medical consent forms. Create a detailed consent form based on the following specific medical situation. 
          
          Structure your response in this format:
          TITLE: [Clear, concise title for the consent form]
          
          CONTENT:
          [Full content of the consent form including risks, considerations, and acknowledgments]
          
          The content should include:
          1. A clear introduction
          2. Detailed explanation of the procedure
          3. Specific risks and considerations
          4. Patient acknowledgment statements
          5. Legal disclaimers
          
          Format the content using HTML for better presentation (p, ul, li, strong tags).`
        },
        { 
          role: "user", 
          content: situation 
        }
      ],
      temperature: 0.7,
      max_tokens: 2000
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error('No response generated');
    }

    // Parse the response content
    const titleMatch = content.match(/TITLE:\s*(.+?)(?=\n\s*CONTENT:)/s);
    const contentMatch = content.match(/CONTENT:\s*(.+)$/s);

    if (!titleMatch || !contentMatch) {
      throw new Error('Invalid response format');
    }

    return {
      title: titleMatch[1].trim(),
      content: contentMatch[1].trim()
    };
  } catch (error) {
    console.error('OpenAI API Error:', error);
    throw new Error('Failed to generate consent form');
  }
};

export const generateResponse = async (prompt: string, location?: { country: string; city: string }) => {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: prompt }
      ],
      temperature: 0.7,
      max_tokens: 1000,
    });

    return response.choices[0]?.message?.content || 'No response generated';
  } catch (error) {
    console.error('OpenAI API Error:', error);
    throw new Error('Failed to generate response');
  }
};